git clone https://github.com/MltrCyber/MltrCyber123
cd MltrCyber123
sh 1.sh
